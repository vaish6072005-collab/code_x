import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env

OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")